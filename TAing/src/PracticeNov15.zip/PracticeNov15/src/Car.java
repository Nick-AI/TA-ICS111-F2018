
public class Car extends Vehicle{
	
	//as additional instance variables, this class should have:
	//the number of wheels
	//how much horsepower the car has
	//how much fuel is left in the car
	
	//the constructor should initialize x, y, the name, number of wheels, and horsepower
	//according to parameters
	//it should also initialize fuel as 100 and the terrain as Ground
	
	
	//the move method should take one additional parameter indicating
	//how much fuel is used for the movement
	//when executing the method, you should also subtract from the fuel variable
}
