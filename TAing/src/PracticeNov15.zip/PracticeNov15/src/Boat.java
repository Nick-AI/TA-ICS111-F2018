
public class Boat extends Vehicle{

	public Boat(int lon, int lat, String n){
		super("Water");
		posX = lon;
		posY = lat;
		name = n;
	}
	
	public void sink(){
		posX = -1;
		posY = -1;
	}
	
	public void move(int xSpeed, int ySpeed){
		super.move(xSpeed, ySpeed);
		
		//only works reliably for speed-increments<10
		if(posY > 90 || posY < -90){
			posY= (-posY) - posY%10;
		}
		if(posX>180 || posX<-180){
			posX = (-posX) - posX%10;
		}
	}

}
