
public class SpaceShip extends Vehicle{

	//as additional instance variables, this class should have:
	//an integer keeping track of height
	//a String keeping track of the ship's destination
	
	
	//the constructor should initialize the height at zero,
	//set the terrain to space and keep the destination blank
	
	//the spaceship should have a fly method
	//this method should modify the ship's height variable
	//then it should call the parent's move method to change its x and y position
	
	//it should have a setDestination method (self explanatory)
	
	
}
