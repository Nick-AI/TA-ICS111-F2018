
public class Submarine extends Boat{

	public int depth;
	
	public Submarine(int lon, int lat, int depth, String n){
		super(lon, lat, n);
		this.depth = 0;
	}
	
	public void dive(int diveSpeed){
		depth += diveSpeed;
	}
	
	public void move(int latSpeed, int lonSpeed, int diveSpeed){
		posX += lonSpeed;
		posY += latSpeed;
		dive(diveSpeed);
	}
}
