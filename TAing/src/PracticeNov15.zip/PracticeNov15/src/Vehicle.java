
public class Vehicle {

	public int posX;
	public int posY;
	public String name;
	public final String TERRAIN;
	
	public Vehicle(int x, int y, String n, String t){
		posX = x;
		posY = y;
		name = n;
		TERRAIN = t;
	}
	
	public Vehicle(String t){
		TERRAIN = t;
	}
	
	public Vehicle(){
		TERRAIN = "unknown";
	}
	
	public void move(int xSpeed, int ySpeed){
		posX += xSpeed;
		posY += ySpeed;
	}
}
